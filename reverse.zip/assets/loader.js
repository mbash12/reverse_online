async function loadResources(resources) {
  console.log(resources);
  return resources;
}
